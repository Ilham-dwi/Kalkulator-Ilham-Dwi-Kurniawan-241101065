/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;


/**
 *
 * @author ASUS
 */
public class Kalkulator_Ilham {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int pilihan;
        
        do {
            System.out.println ("== Kalkulator Sederhana ==");
            System.out.println("1. penjumlahan");
            System.out.println("2. pengurangan");
            System.out.println("3. perkalian");
            System.out.println("4. pembagian");
            System.out.println("5. pengkuadratan");
            System.out.println("6. Pengakaran");
            System.out.println("0. Keluar");
            System.out.println ("==========================");
            System.out.print ("pilih oprasi: ");
            pilihan = input.nextInt();
            
            
            switch (pilihan) {
                    case 1:
                        new penjumlahan(mintaAngka("masukan angka peratma: "), mintaAngka("masukan angka kedua: "),"hasil penjumlahan = ");
                        break;
                    case 2:
                        new pengurangan(mintaAngka("masukan angka peratma: "), mintaAngka("masukan angka kedua: "),"hasil pengurangan = ");
                        break;
                    case 3:
                        new perkalian(mintaAngka("masukan angka peratma: "), mintaAngka("masukan angka kedua: "),"hasil perkalian = ");
                        break;
                    case 4:
                        new pembagian(mintaAngka("masukan angka peratma: "), mintaAngka("masukan angka kedua: "),"hasil pembagian = ");
                        break;
                    case 5:
                        new pengkuadratan(mintaAngka("masukan angka peratma: "), mintaAngka("masukan angka kedua: "),"hasil pengkuadratan = ");
                        break;
                    case 6:
                        new pengakaran(mintaAngka("masukan angka peratma: "),"hasil pengakaran = ");
                        break;
                    case 0:
                        System.out.println("terimakasih!");
                        break;
                    default:
                       System.out.println("Pilihan tidak valid!");
                       
            }System.out.println();
            
                    
        }while (pilihan != 0);
       
    }static double mintaAngka(String pesan) {
        Scanner input = new Scanner(System.in);
        System.out.print(pesan);
        return input.nextDouble();
    }
    private static class penjumlahan {
        public penjumlahan(double a, double b, String k) {
            System.out.println(k + (a + b));
        }
    }

    private static class pengurangan {
        public pengurangan(double a, double b, String k) {
            System.out.println(k + (a - b));
        }
    }

    private static class perkalian {
        public perkalian(double a, double b, String k) {
            System.out.println(k + (a * b));
        }
    }

    private static class pembagian {
        public pembagian(double a, double b, String k) {
            if (b == 0)
                System.out.println("Error: Tidak bisa membagi dengan nol!");
            else
                System.out.println(k + (a / b));
        }
    }

    private static class pengkuadratan {
        public pengkuadratan(double a, double b, String k) {
            System.out.println(k + Math.pow(a, b));
        }
    }

    private static class pengakaran {
        public pengakaran(double a, String k) {
            if (a < 0)
                System.out.println("Error: Tidak bisa akar bilangan negatif!");
            else
                System.out.println(k + Math.sqrt(a)+);
        }
}
