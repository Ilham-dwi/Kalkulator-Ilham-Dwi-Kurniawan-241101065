/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
package kalkulator.il;

/**
 *
 * @author User-15
 */
public class KalkulatorIL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       penjumlahan jumlah = new penjumlahan (10,5,"hasil penjumlahan = ");
       pengurangan kurang = new pengurangan (10,5,"hasil pengurangan = ");
       perkalian kali = new perkalian (10,5,"hasil perkalian = ");
       pembagian bagi = new pembagian (10,5,"hasil pembagian = ");
       pengkuadratan kuadrat = new pengkuadratan (10,2,"hasil kuadrat = ");
       pengakaran akar = new pengakaran (9, "hasil pengakaran = ");
        
    }

    private static class penjumlahan {

        public penjumlahan(int a, int b, String k) {
            System.out.print(k);
            System.out.println(a+b);
            
        }
    }

    private static class pengurangan {

        public pengurangan(int a, int b, String k) {
            System.out.print(k);
            System.out.println(a-b);
        }
    }

    private static class perkalian {

       public perkalian(int a, int b, String k) {
            System.out.print(k);
            System.out.println(a*b);
        }
    }

    private static class pembagian {

        public pembagian(int a, int b, String k) {
            System.out.print(k);
            System.out.println(a/b);
        }
    }

    private static class pengkuadratan {

        public pengkuadratan(int a, int b, String k) {
            System.out.print(k);
            System.out.println(Math.pow(a,b));
        }
    }

    private static class pengakaran {

         public pengakaran(int a, String k) {
            System.out.print(k);
            System.out.println(Math.sqrt(a));
        }
    }
   
 